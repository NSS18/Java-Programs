/*Write Java program for calculation with all methods addition,subtraction,multiplication and division.All method
 should be with parameter and no return type*/


public class Calculation{

    //No return type - With parameters STATIC method of addition

    public static void addition(int no1, int no2){
        System.out.println("Addition of "+no1+" and "+no2+" : ");
        System.out.println(no1+no2);

    }

    //No return type - With parameters STATIC method of subtraction

    public static void subtraction(int no1, int no2){
        System.out.println("subtraction of "+no1+" and "+no2+" : ");
        System.out.println(no1-no2);

    }

    //No return type - With parameters STATIC method of multiplication

    public static void multiplication(int no1, int no2){
        System.out.println("Multiplication of "+no1+" and "+no2+" : ");
        System.out.println(no1*no2);

    }

    //No return type - With parameters STATIC method of division

    public static void division(int no1, int no2){
        System.out.println("Division of "+no1+" and "+no2+" : ");
        System.out.println(no1/no2);

    }

    //main method

    public static void main(String[] args) {
        System.out.println("Calculation of two numbers: ");
        addition(20,34);    //Static method addition can come direct in static main method area
        subtraction(30,23);  //Static method subtraction can come direct in static main method area
        multiplication(20,5);  //Static method multiplication can come direct in static main method area
        division(30,5);        //Static method division can come direct in static main method area


    }



}
